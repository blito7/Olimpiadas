<?php
echo "PHP FUNCIONA";
