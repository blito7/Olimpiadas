<?php
echo password_hash('admin_1234', PASSWORD_DEFAULT);
?>